#include "mex.h"
#include <malloc.h>
#include <math.h>
#include "omp.h"

///////////////////////////////////////////////////////////
// compile with: mex CXXFLAGS="\$CXXFLAGS -fopenmp" LDFLAGS="\$LDFLAGS -fopenmp" mex_convolution.cpp
///////////////////////////////////////////////////////////
// entry function
double filter_response(int filter_size, double *Src, double *filter, int col, int row, int nRow);

void mexFunction(int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[]) {
    double *input,*output,*filter;
	int filter_size,nRow,nCol,N;
	if (nrhs !=4 ||  nlhs!=1)
		mexErrMsgTxt("Invalid number of input/output arguments!");
	input = mxGetPr(prhs[0]);
	filter = mxGetPr(prhs[1]);
	filter_size = mxGetM(prhs[1]);
	nRow = mxGetScalar(prhs[2]);
	nCol = mxGetScalar(prhs[3]);
	N = (filter_size - 1)/2;
	plhs[0] = mxCreateDoubleMatrix(nRow*nCol,1,mxREAL);
	output = mxGetPr(plhs[0]);
	if (filter_size != mxGetN(prhs[1]) || filter_size%2 != 1)
		mexErrMsgTxt("Invalid filter(only valid for square and odd size filter)!");
	//handle central region
	int pCol = (int)nCol/8;
#pragma omp parallel sections num_threads(4)
	{
#pragma omp section
		{
//	printf("section 1 thread=%d\n",omp_get_thread_num());
	for (int col = N; col < pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}					
#pragma omp section
		{
//	printf("section 2 thread=%d\n",omp_get_thread_num());
	for (int col = pCol; col < 2*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
	for (int col = 2*pCol; col < 3*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
	for (int col = 3*pCol; col < 4*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
	for (int col = 4*pCol; col < 5*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
	for (int col = 5*pCol; col < 6*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
	for (int col = 6*pCol; col < 7*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
	for (int col = 7*pCol; col < nCol-N; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
// handle boundaries

#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
    for (int col = 0; col < N; col++)
	{
		for (int row = 0; row < nRow; row++)
		{
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_col < 0)
						idx_col = -1 - idx_col;
					if (idx_row < 0)
						idx_row = -1 - idx_row;
					if (idx_row >= nRow)
						idx_row = 2*nRow - (idx_row+1);
					response = response + input[idx_row + idx_col*nRow] * filter[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
	}
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
    for (int col = nCol-N; col < nCol; col++)
	{
		for (int row = 0; row < nRow; row++)
		{
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_col >= nCol)
						idx_col = 2*nCol - (idx_col+1);
					if (idx_row < 0)
						idx_row = -1 - idx_row;
					if (idx_row >= nRow)
						idx_row = 2*nRow - (idx_row+1);
					response = response + input[idx_row + idx_col*nRow] * filter[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
	}
}
#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
    for (int col = N; col < nCol-N; col++)
	{
		for (int row = 0; row < N; row++)
		{
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_row < 0)
						idx_row = -1 - idx_row;
					response = response + input[idx_row + idx_col*nRow] * filter[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
	}
}
#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
    for (int col = N; col < nCol-N; col++)
	{
		for (int row = nRow-N; row < nRow; row++)
		{
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_row >= nRow)
						idx_row = 2*nRow - (idx_row+1);
					response = response + input[idx_row + idx_col*nRow] * filter[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
	}
}
	}
}
double filter_response(int filter_size, double *Src, double *filter, int col, int row, int nRow){
	int idx_col,idx_row;
	double response = 0;
	int N = (filter_size - 1)/2;
	for (int filter_col = -N; filter_col<=N; filter_col++)
	{
		for (int filter_row = -N; filter_row<=N; filter_row++)
		{
			idx_col = col + filter_col;
			idx_row = row + filter_row;
			response = response + Src[idx_row + idx_col*nRow] * 
				filter[filter_row + N + (filter_col + N)*filter_size];
		}
	}
	return response;
}

