#include "mex.h"
#include <stdlib.h>
#include <math.h>
#include "omp.h"

///////////////////////////////////////////////////////////
// compile with: mex CXXFLAGS="\$CXXFLAGS -fopenmp" LDFLAGS="\$LDFLAGS -fopenmp" mex_convolution_transpose.cpp
///////////////////////////////////////////////////////////
// entry function
double filter_response(int filter_size, double *Src, double *filter, int col, int row, int nRow);

void mexFunction(int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[]) {
    double *input,*output,*k,*filter;
	int filter_size,nRow,nCol,N;
	if (nrhs !=4 ||  nlhs!=1)
		mexErrMsgTxt("Invalid number of input/output arguments!");
	input = mxGetPr(prhs[0]);
	k = mxGetPr(prhs[1]);
	filter_size = mxGetM(prhs[1]);
	nRow = mxGetScalar(prhs[2]);
	nCol = mxGetScalar(prhs[3]);
	N = (filter_size - 1)/2;
	plhs[0] = mxCreateDoubleMatrix(nRow*nCol,1,mxREAL);
	output = mxGetPr(plhs[0]);
	if (filter_size != mxGetN(prhs[1]) || filter_size%2 != 1)
		mexErrMsgTxt("Invalid filter(only valid for square and odd size filter)!");
//	reverse filter
	filter = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
	for (int idx = 0; idx < filter_size*filter_size; idx++)
		filter[idx] = k[filter_size*filter_size - idx - 1];
    
    //handle central region
	int pCol = (int)nCol/8;
#pragma omp parallel sections num_threads(4)
	{
#pragma omp section
		{
//	printf("section 1 thread=%d\n",omp_get_thread_num());
	for (int col = N; col < pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}					
#pragma omp section
		{
//	printf("section 2 thread=%d\n",omp_get_thread_num());
	for (int col = pCol; col < 2*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
	for (int col = 2*pCol; col < 3*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
	for (int col = 3*pCol; col < 4*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
	for (int col = 4*pCol; col < 5*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
	for (int col = 5*pCol; col < 6*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 3 thread=%d\n",omp_get_thread_num());
	for (int col = 6*pCol; col < 7*pCol; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
	for (int col = 7*pCol; col < nCol-N; col++)
		for (int row = N; row < nRow-N; row++)
			output[row + col*nRow] = filter_response(filter_size,input,filter,col,row,nRow);
}
// handle boudaryies
#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
	//left side boundary
	for (int col = 0; col < N; col++)
	{
		double *temp_filter = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
		for (int idx_col = 0; idx_col < N-col; idx_col++)
		{
			for (int idx_row = 0; idx_row < filter_size; idx_row++)
				temp_filter[idx_row + idx_col*filter_size] = filter[idx_row + (2*N-idx_col)*filter_size];
		}
		for (int idx_col = N-col; idx_col < filter_size; idx_col++)
		{
			for (int idx_row = 0; idx_row < filter_size; idx_row++)
				temp_filter[idx_row + idx_col*filter_size] = filter[idx_row + idx_col*filter_size];
		}
		for (int row = N; row < nRow-N; row++)
		{
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_col < 0)
						idx_col = -1 - idx_col;
					response = response + input[idx_row + idx_col*nRow] * temp_filter[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
	}
}
#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
	//right side boundary
	for (int col = nCol-N; col < nCol; col++)
	{
		double *temp_filter = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
		for (int idx_col = 0; idx_col < N-(nCol-col)+1; idx_col++)
		{
			for (int idx_row = 0; idx_row < filter_size; idx_row++)
				temp_filter[idx_row + (2*N-idx_col)*filter_size] = filter[idx_row + idx_col*filter_size];
		}
		for (int idx_col = N-(nCol-col)+1; idx_col < filter_size; idx_col++)
		{
			for (int idx_row = 0; idx_row < filter_size; idx_row++)
				temp_filter[idx_row + (2*N-idx_col)*filter_size] = filter[idx_row + (2*N-idx_col)*filter_size];
		}
		for (int row = N; row < nRow-N; row++)
		{
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_col >= nCol)
						idx_col = 2*nCol - (idx_col+1);
					response = response + input[idx_row + idx_col*nRow] * temp_filter[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
	}
}
#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
	//top boundary
	for (int row = 0; row < N; row++)
	{
		double *temp_filter = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
		for (int idx_row = 0; idx_row < N-row; idx_row++)
		{
			for (int idx_col = 0; idx_col < filter_size; idx_col++)
				temp_filter[idx_row + idx_col*filter_size] = filter[2*N - idx_row + idx_col*filter_size];
		}
		for (int idx_row = N-row; idx_row < filter_size; idx_row++)
		{
			for (int idx_col = 0; idx_col < filter_size; idx_col++)
				temp_filter[idx_row + idx_col*filter_size] = filter[idx_row + idx_col*filter_size];
		}
		for (int col = N; col < nCol-N; col++)
		{
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_row < 0)
						idx_row = -1 - idx_row;
					response = response + input[idx_row + idx_col*nRow] * temp_filter[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
	}
}
#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
	//bottom boudanry
	for (int row = nRow-N; row < nRow; row++)
	{
		double *temp_filter = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
		for (int idx_row = 0; idx_row < N-(nRow-row)+1; idx_row++)
		{
			for (int idx_col = 0; idx_col < filter_size; idx_col++)
				temp_filter[2*N - idx_row + idx_col*filter_size] = filter[idx_row + idx_col*filter_size];
		}
		for (int idx_row = N-(nRow-row)+1; idx_row < filter_size; idx_row++)
		{
			for (int idx_col = 0; idx_col < filter_size; idx_col++)
				temp_filter[2*N - idx_row + idx_col*filter_size] = filter[2*N - idx_row + idx_col*filter_size];
		}
		for (int col = N; col < nCol-N; col++)
		{
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_row >= nRow)
						idx_row = 2*nRow - (idx_row+1);
					response = response + input[idx_row + idx_col*nRow] * temp_filter[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
	}
}
#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
	//handle left two blocks
	for (int col = 0; col < N; col++)
	{
		double *temp_filter = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
		for (int idx_col = 0; idx_col < N-col; idx_col++)
		{
			for (int idx_row = 0; idx_row < filter_size; idx_row++)
				temp_filter[idx_row + idx_col*filter_size] = filter[idx_row + (2*N-idx_col)*filter_size];
		}
		for (int idx_col = N-col; idx_col < filter_size; idx_col++)
		{
			for (int idx_row = 0; idx_row < filter_size; idx_row++)
				temp_filter[idx_row + idx_col*filter_size] = filter[idx_row + idx_col*filter_size];
		}
		//top block
        int row;
		for (row = 0; row < N; row++)
		{
			double *temp_filter2 = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
			for (int idx_row = 0; idx_row < N-row; idx_row++)
			{
				for (int idx_col = 0; idx_col < filter_size; idx_col++)
					temp_filter2[idx_row + idx_col*filter_size] = temp_filter[2*N - idx_row + idx_col*filter_size];
			}
			for (int idx_row = N-row; idx_row < filter_size; idx_row++)
			{
				for (int idx_col = 0; idx_col < filter_size; idx_col++)
					temp_filter2[idx_row + idx_col*filter_size] = temp_filter[idx_row + idx_col*filter_size];
			}
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_col < 0)
						idx_col = -1 - idx_col;
					if (idx_row < 0)
						idx_row = -1 - idx_row;
					response = response + input[idx_row + idx_col*nRow] * temp_filter2[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
		//bottom block
		for (row = nRow-N; row < nRow; row++)
		{
			double *temp_filter2 = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
			for (int idx_row = 0; idx_row < N-(nRow-row)+1; idx_row++)
			{
				for (int idx_col = 0; idx_col < filter_size; idx_col++)
					temp_filter2[2*N - idx_row + idx_col*filter_size] = temp_filter[idx_row + idx_col*filter_size];
			}
			for (int idx_row = N-(nRow-row)+1; idx_row < filter_size; idx_row++)
			{
				for (int idx_col = 0; idx_col < filter_size; idx_col++)
					temp_filter2[2*N - idx_row + idx_col*filter_size] = temp_filter[2*N - idx_row + idx_col*filter_size];
			}
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_col < 0)
						idx_col = -1 - idx_col;
					if (idx_row >= nRow)
						idx_row = 2*nRow - (idx_row+1);
					response = response + input[idx_row + idx_col*nRow] * temp_filter2[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
	}
}
#pragma omp section
		{
//	printf("section 4 thread=%d\n",omp_get_thread_num());
	//handle right two blocks
	for (int col = nCol-N; col < nCol; col++)
	{
		double *temp_filter = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
		for (int idx_col = 0; idx_col < N-(nCol-col)+1; idx_col++)
		{
			for (int idx_row = 0; idx_row < filter_size; idx_row++)
				temp_filter[idx_row + (2*N-idx_col)*filter_size] = filter[idx_row + idx_col*filter_size];
		}
		for (int idx_col = N-(nCol-col)+1; idx_col < filter_size; idx_col++)
		{
			for (int idx_row = 0; idx_row < filter_size; idx_row++)
				temp_filter[idx_row + (2*N-idx_col)*filter_size] = filter[idx_row + (2*N-idx_col)*filter_size];
		}
        int row;
		//top block
		for (row = 0; row < N; row++)
		{
			double *temp_filter2 = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
			for (int idx_row = 0; idx_row < N-row; idx_row++)
			{
				for (int idx_col = 0; idx_col < filter_size; idx_col++)
					temp_filter2[idx_row + idx_col*filter_size] = temp_filter[2*N - idx_row + idx_col*filter_size];
			}
			for (int idx_row = N-row; idx_row < filter_size; idx_row++)
			{
				for (int idx_col = 0; idx_col < filter_size; idx_col++)
					temp_filter2[idx_row + idx_col*filter_size] = temp_filter[idx_row + idx_col*filter_size];
			}
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_col >= nCol)
						idx_col = 2*nCol - (idx_col+1);
					if (idx_row < 0)
						idx_row = -1 - idx_row;
					response = response + input[idx_row + idx_col*nRow] * temp_filter2[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
		//bottom block
		for (row = nRow-N; row < nRow; row++)
		{
			double *temp_filter2 = (double *)mxCalloc(filter_size*filter_size,sizeof(double));
			for (int idx_row = 0; idx_row < N-(nRow-row)+1; idx_row++)
			{
				for (int idx_col = 0; idx_col < filter_size; idx_col++)
					temp_filter2[2*N - idx_row + idx_col*filter_size] = temp_filter[idx_row + idx_col*filter_size];
			}
			for (int idx_row = N-(nRow-row)+1; idx_row < filter_size; idx_row++)
			{
				for (int idx_col = 0; idx_col < filter_size; idx_col++)
					temp_filter2[2*N - idx_row + idx_col*filter_size] = temp_filter[2*N - idx_row + idx_col*filter_size];
			}
			int idx = 0;
			int idx_col,idx_row;
			double response = 0;
			for (int filter_col = -N; filter_col<=N; filter_col++)
			{
				for (int filter_row = -N; filter_row<=N; filter_row++)
				{
					idx_col = col + filter_col;
					idx_row = row + filter_row;

					if (idx_col >= nCol)
						idx_col = 2*nCol - (idx_col+1);
					if (idx_row >= nRow)
						idx_row = 2*nRow - (idx_row+1);
					response = response + input[idx_row + idx_col*nRow] * temp_filter2[idx];
					idx++;
				}
			}
			output[row + col*nRow] = response;
		}
	}
}
	}
}
double filter_response(int filter_size, double *Src, double *filter, int col, int row, int nRow){
	int idx_col,idx_row;
	double response = 0;
	int N = (filter_size - 1)/2;
	for (int filter_col = -N; filter_col<=N; filter_col++)
	{
		for (int filter_row = -N; filter_row<=N; filter_row++)
		{
			idx_col = col + filter_col;
			idx_row = row + filter_row;
			response = response + Src[idx_row + idx_col*nRow] * 
				filter[filter_row + N + (filter_col + N)*filter_size];
		}
	}
	return response;
}

